<h1>{{ translate('Message') }}</h1>
<p>{{ $content }}</p>
<p><b>{{ translate('Sender') }}:</b>{{ $sender }}</p>
<p><b>{{ translate('Message') }}:</b>{{ $details }}</p>
<a class="btn btn-primary btn-md" href="{{ $link }}">{{ translate('See Details') }}</a>
